<ul>
  <li>
    <a href="user_dashboard.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Dashboard</span>
    </a>
  </li>
  <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>Media Files</span>
    </a>
  </li>
  <!--We are skipping this sub modules for now..
    <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
       <li><a href="product.php">Manage Products</a> </li>
       <li><a href="add_product.php">Add Products</a> </li>
   </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-credit-card"></i>
       <span>Sales</span>
      </a>
      <ul class="nav submenu">
         <li><a href="sales.php">Manage Sales</a> </li>
         <li><a href="add_sale.php">Add Sale</a> </li>
     </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-duplicate"></i>
       <span>Sales Report</span>
      </a>
      <ul class="nav submenu">
        <li><a href="sales_report.php">Sales by dates </a></li>
        <li><a href="monthly_sales.php">Monthly sales</a></li>
        <li><a href="daily_sales.php">Daily sales</a> </li>
      </ul>
  </li>
  -->
  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Categories</span>
    </a>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
       <span>Inventory</span>
      </a>
      <ul class="nav submenu">
      <li><a href="cookery_lab.php">Cookery</a></li>
      <li><a href="foodbev_lab.php">Food & Beverages</a></li>
      <li><a href="pastry_lab.php">Bread & Pastry</a></li>
      <li><a href="bartending_lab.php">Bartending</a></li>
      <li><a href="housekeeping_lab.php">Houskeeping</a></li>
      <li><a href="frontoffices_lab.php">Front Offices</a></li>
      <li><a href="barista_lab.php">Barista</a></li>
      </ul>
  </li>
  <li>
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-folder-close"></i>
       <span>Reports</span>
      </a>
      <ul class="nav submenu">
      <!--<li><a href="cookery_lab_reports.php">Cookery</a></li>
      <li><a href="foodbev_lab_reports.php">Food & Beverages</a></li>
      <li><a href="pastry_lab_reports.php">Bread & Pastry</a></li>-->
      <li><a href="cookery_lab_damage_reports.php">Damage Report</a></li>
      <!--<li><a href="expiry_reports.php">Expiry Report</a></li>-->
      <li><a href="cookery_lab_stock_reports.php">Stock Report</a></li>
      <li><a href="cookery_lab_summary_reports.php">Summary Report</a></li>
      </ul>
  </li>