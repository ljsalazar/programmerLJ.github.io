<?php
$page_title = 'All Items';
require_once('includes/load.php');
// Checkin What level user has permission to view this page
 page_require_level(3);
$products = join_item_table();
//fetch.php



$products = array('serialno', 'name', 'category', 'quantity', 'damage_item', 'description', 'remarks');

$query = "SELECT * FROM item ";

if(isset($_POST['search']['value']))
{
 $query .= '
 WHERE serialno LIKE "%'.$_POST['search']['value'].'%" 
 OR name LIKE "%'.$_POST['search']['value'].'%" 
 OR category LIKE "%'.$_POST['search']['value'].'%" 
 OR quantity LIKE "%'.$_POST['search']['value'].'%" 
 OR damage_item LIKE "%'.$_POST['search']['value'].'%" 
 OR description LIKE "%'.$_POST['search']['value'].'%" 
 OR remarks LIKE "%'.$_POST['search']['value'].'%" 
 ';
}

if(isset($_POST['order']))
{
 $query .= 'ORDER BY '.$products[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' ';
}
else
{
 $query .= 'ORDER BY id DESC ';
}

$query1 = '';

if($_POST['length'] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

$statement = $db->prepare($query);

$statement->execute();

$number_filter_row = $statement->rowCount();

$statement = $db->prepare($query . $query1);

$statement->execute();

$result = $statement->fetchAll();

$data = array();

foreach($result as $row)
{
 $sub_array = array();
 $sub_array[] = $row['serialno'];
 $sub_array[] = $row['name'];
 $sub_array[] = $row['category'];
 $sub_array[] = $row['quantity'];
 $sub_array[] = $row['damage_item'];
 $sub_array[] = $row['description'];
 $sub_array[] = $row['remarks'];
 $data[] = $sub_array;
}

function count_all_data($connect)
{
 $query = "SELECT * FROM item";
 $statement = $db->prepare($query);
 $statement->execute();
 return $statement->rowCount();
}

$output = array(
 'draw'    => intval($_POST['draw']),
 'recordsTotal'  => count_all_data($connect),
 'recordsFiltered' => $number_filter_row,
 'data'    => $data
);

echo json_encode($output);

?>