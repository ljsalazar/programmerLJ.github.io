<?php
  $page_title = 'Summary Reports';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
  $products = join_foodbev_table();
?>
<?php include_once('layouts/header.php'); ?>

  <div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
        <div class="pull-right">
         <form action="foodbev_export_file.php" method="post">
          <input type="submit" class="btn btn-success" name="export_excel" value="Download"/>
          </form>
         </div>
        <h2>Food & Beverages Laboratory Reports</h2>
        <div class="btn-group">
        <a href="cookery_lab_summary_reports.php" class="btn btn-default">Cookery</a>
        <a href="foodbev_lab_summary_reports.php" class="btn btn-primary">Food&Beverages</a>
        <a href="pastry_lab_summary_reports.php" class="btn btn-default">Bread&Pastry</a>
        <a href="bartending_lab_summary_reports.php" class="btn btn-default">Bartending</a>
        <a href="housekeeping_lab_summary_reports.php" class="btn btn-default">Housekeeping</a>
        <a href="frontoffices_lab_summary_reports.php" class="btn btn-default">Front Offices</a>
        <a href="barista_lab_summary_reports.php" class="btn btn-default">Barista</a>
        </div>
           <!--<a href="add_item.php" class="btn btn-primary">Add New</a>
          <div class="btn-group" role="group" aria-label="...">
           </div> 
          <input type="submit" class="btn btn-success" name="export_copy" value="Copy"/>
           <input type="submit" class="btn btn-success" name="export_csv" value="CSV"/>
           <input type="submit" class="btn btn-success" name="export_pdf" value="PDF"/>
           <input type="submit" class="btn btn-success" name="export_print" value="Print"/>
          -->
         </div>
        </div>
        <div class="panel-body">
          <!--<table class="table table-bordered"> datatablesSimple-->
          <table id="datatablesSimple" class="table-striped table-bordered table-hover" style="width:100%">
            <thead>
              <tr>
                <th class="text-center" style="width: 50px;">Serial#</th>
                <th> Item Name</th>
                <th class="text-center" style="width: 10%;"> Categories </th>
                <th class="text-center" style="width: 10%;"> In-Stock </th>
                <th class="text-center" style="width: 10%;"> Damage Quantity </th>
                <th class="text-center" style="width: 10%;"> Total Stock </th>
                <th class="text-center" style="width: 10%;"> Item Added </th>
                <th class="text-center" style="width: 10%;"> Description </th>
                <th class="text-center" style="width: 10%;"> Remarks </th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($products as $product):?>
              <tr>
                <td class="text-center"><?php echo remove_junk(($product['serialno']));?></td>
                <td><?php echo remove_junk($product['name']); ?></td>                                
                <td class="text-center"> <?php echo remove_junk($product['category']); ?></td>
                <td class="text-center"> <?php echo remove_junk($product['quantity']); ?></td>
                <td class="text-center"> <?php echo remove_junk($product['damage_item']); ?></td>
                <td class="text-center"> <?php echo remove_junk($product['quantity'] + $product['damage_item']); ?></td>
                <td class="text-center"> <?php echo read_date($product['date_time']); ?></td>
                <td><?php echo remove_junk($product['description']); ?></td>
                <td><?php echo remove_junk($product['remarks']); ?></td>
              </tr>
             <?php endforeach; ?>
            </tbody>
          </tabel>
        </div>
      </div>
    </div>
  </div>
  <!--This script is for the datagrid tables...-->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="dist/js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="dist/js/datatables-simple-demo.js"></script>

  <?php include_once('layouts/footer.php'); ?>
