
<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(2);
?>
<?php $find_media = find_by_id('media',(int)$_GET['id']);

if(isset($_POST["id"]) && !empty($_POST["id"])){
    $id = $_POST["id"];
    redirect('delete_media.php');
}
else{
    if(empty(trim($_GET["id"]))){
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}

?>
<?php include_once('layouts/header.php'); ?>
<!--Modal Fade for Delete panel...-->
<div class="panel panel-default" style="width: 50%;">
      <div class="panel-heading">
        <a href="media.php" class="close" aria-label="Close"><span aria-hidden="true">&times;</span></a>
        <h3 class="panel-title">Delete</h3>
      </div>
      <form action="delete_media_confirmation.php" method="post">
      <div class="panel-body">   
        <p>Are you sure you want to delete this image ?</p>
      </div>
      <div class="panel-footer">
      <input type="text" name="id" value="<?php echo trim($_GET["id"]); ?>"/>
        <a href="media.php" class="btn btn-default">Cancel</a>
        <input type="submit" class="btn btn-danger btn-xs" value="DELETE" title="delete">
</form>
      </div>
</div><!-- /.Delete panel panel-default-->

<?php include_once('layouts/footer.php'); ?>
