<?php
  $page_title = 'Barista';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
  $products = join_barista_table();

?>
<!--Body...-->
<?php

$output = '';
if(isset($_POST["export_excel"]))
{
  $output .= '
   <table id="datatablesSimple" class="table-striped table-bordered table-hover" bordered="4" style="width:100%">
   <thead>  
                    <tr>  
                         <th>Serial no.</th>  
                         <th>Item Name</th>  
                         <th>Category</th>  
                         <th>Quantity</th>  
                         <th>Expiration Date</th>  
                         <th>Damage Item</th>
                         <th>Total stock</th>  
                         <th>Item Added</th> 
                         <th>Description</th>
                         <th>Remarks</th>  
                    </tr>
                    </thead>
  ';
  foreach ($products as $product){
  $productstock = intval($product['quantity'] + $product['damage_item']);
   $output .= '
   <tbody>
                    <tr>  
                         <td> '.$product["serialno"]. '</td>  
                         <td> '.$product["name"]. '</td>  
                         <td> '.$product["category"]. '</td>  
                         <td> '.$product["quantity"]. '</td>  
                         <td> '.$product["expiry_date"]. '</td>  
                         <td> '.$product["damage_item"]. '</td>  
                         <td> '.$productstock.'</td>
                         <td> '.$product["date_time"]. '</td>  
                         <td> '.$product["description"]. '</td>  
                         <td> '.$product["remarks"]. '</td>
                    </tr>
                    </tbody>
   ';
}
  $output .= '</table>';
  date_default_timezone_set('Asia/Manila');
  $date = date("F j, Y, g:i a");
  $title = $date."_". "report.xls";
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename="'.$title.'" ');
  echo $output;
 }

?>