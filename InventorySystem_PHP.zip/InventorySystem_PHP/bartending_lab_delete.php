<?php
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
  page_require_level(2);
  $user = current_user();
   $all_users = find_all_user();
?>
<?php
  $item = find_by_id('bartending',(int)$_GET['id']);
  if(!$item){
    $session->msg("d","Missing Item id.");
    redirect('bartending_lab.php');
  }
?>
<?php
include_once ('includes/activitylog.inc.php');
  $delete_id = delete_by_id('bartending',(int)$item['id']);
  if($delete_id){
      $session->msg("s","Item deleted.");
      //================================================
                 //Activity Log
                 $ip = $_SERVER['REMOTE_ADDR']; //client IP
                 date_default_timezone_set('Asia/Manila');
                 $time = date("F j, Y, h:iA", time());
                 $itemserialno = $item['serialno'];
                 //user attributes
                 $currentUserID = (int)$user['id'];
                 $currentUser = $user['name'];
                 $userlevel = (int)$user['user_level'];
                 //condition for userlevel defining user role
                 if($userlevel == '1'){
                  $userRole = "Admin";
                 }
                 else{
                  $userRole = "User";
                 }
                 $logactivity = "Item #$itemserialno-" .$item['name']. " was Deleted by $currentUser($userRole) On $time";
                  activitylog($logactivity);
                //Query Statement for activity log
                $query  = "INSERT INTO activitylog (";
                $query .=" name,action,ip";
                $query .=") VALUES (";
                $query .=" '{$currentUser}', '{$logactivity}', '{$ip}' ";
                $query .=")";
                $query .=" ON DUPLICATE KEY UPDATE name='{$currentUser}'";
                $db->query($query);             
                 //==================================================
      redirect('bartending_lab.php');
  } else {
      $session->msg("d","Item deletion failed.");
      redirect('bartending_lab.php');
  }
?>
