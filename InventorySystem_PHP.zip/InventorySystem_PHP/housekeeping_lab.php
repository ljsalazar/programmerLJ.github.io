<?php
  $page_title = 'Housekeeping';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
  $products = join_housekeeping_table();
?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
     <div class="col-md-12">
       <?php echo display_msg($msg); ?>
     </div>
    <div class="col-md-12">
      <div class="panel panel-default">
        <div class="panel-heading clearfix">
          <h2>Housekeeping Laboratory</h2>
         <div class="pull-right">
           <a href="housekeeping_lab_add.php" class="btn btn-primary">Add New</a>
         </div>
        </div>
        <div class="panel-body">
          <!--<table class="table table-bordered" class="table table-sm table-striped table-bordered table-hover" style="width:100%">-->
            <table id="datatablesSimple" class="table-striped table-bordered table-hover" style="width:100%">
            <thead>
              <tr>
                <th class="text-center" style="width: 50px;">Serial#</th>
                <th> Photo</th>
                <th> Item Name</th>
                <th class="text-center" style="width: 10%;"> Categories </th>
                <th class="text-center" style="width: 10%;"> In-Stock </th>
                <th class="text-center" style="width: 10%;"> Date Added </th>
                <th class="text-center" style="width: 10%;"> Description </th>
                <th class="text-left" style="width: 100px;"> Actions </th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($products as $product):?>
              <tr>
                <td class="text-center"><?php echo remove_junk(($product['serialno']));?></td>
                <td>
                  <?php if($product['media_id'] === '0'): ?>
                    <img class="img-avatar img-square" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                    <img class="img-avatar img-square" src="uploads/products/<?php echo $product['image']; ?>" alt="">
                <?php endif; ?>
                </td>
                <td><?php echo remove_junk($product['name']); ?></td>                                
                <td class="text-center"> <?php echo remove_junk($product['category']); ?></td>
                <td class="text-center"> <?php echo remove_junk($product['quantity']); ?></td>
                <td class="text-center"> <?php echo read_date($product['date_time']); ?></td>
                <td><?php echo remove_junk($product['description']); ?></td>
                <td class="text-center">
                  <div class="btn-group">
                    <a href="housekeeping_lab_edit.php?id=<?php echo (int)$product['id'];?>" class="btn btn-info btn-xs"  title="Edit" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-edit"></span>
                    </a>
                    <a href="housekeeping_lab_delete.php?id=<?php echo (int)$product['id'];?>" class="btn btn-danger btn-xs"  title="Delete" data-toggle="tooltip">
                      <span class="glyphicon glyphicon-trash"></span>
                    </a>
                  </div>
                </td>
              </tr>
             <?php endforeach; ?>
            </tbody>
          </tabel>
        </div>
      </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="dist/js/scripts.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="dist/js/datatables-simple-demo.js"></script>
        
  <?php include_once('layouts/footer.php'); ?>