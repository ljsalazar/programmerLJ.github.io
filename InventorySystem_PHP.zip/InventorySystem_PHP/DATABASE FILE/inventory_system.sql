-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2021 at 06:58 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `activitylog`
--

CREATE TABLE `activitylog` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `action` text DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activitylog`
--

INSERT INTO `activitylog` (`id`, `name`, `action`, `ip`, `updated_at`) VALUES
(21, 'Peter', 'Item #BPP001-Baking Soda was Updated by Peter(User) On August 5, 2021, 08:55PM', '127.0.0.1', '2021-08-05 12:55:34'),
(22, 'Admin', 'Item #COK003-Boning Knife was Updated by Admin(Admin) On August 6, 2021, 10:59AM', '127.0.0.1', '2021-08-06 02:59:59'),
(23, 'Admin', 'Item #COK001-Chef Knife was Updated by Admin(Admin) On August 6, 2021, 11:06AM', '127.0.0.1', '2021-08-06 03:06:48'),
(24, 'Admin', 'Item #COK001-Chef Knife was Updated by Admin(Admin) On August 6, 2021, 11:07AM', '127.0.0.1', '2021-08-06 03:07:01'),
(25, 'Admin', 'Item #COK001-Chef Knife was Updated by Admin(Admin) On August 6, 2021, 01:11PM', '127.0.0.1', '2021-08-06 05:11:59'),
(26, 'Admin', 'Item #COK001-Chef Knife was Updated by Admin(Admin) On August 6, 2021, 01:15PM', '127.0.0.1', '2021-08-06 05:15:52'),
(27, 'Admin', 'Item #COK002-Cleaver Knife was Updated by Admin(Admin) On August 6, 2021, 01:16PM', '127.0.0.1', '2021-08-06 05:16:08'),
(28, 'Admin', 'Item #COK002-Cleaver Knife was Updated by Admin(Admin) On August 6, 2021, 01:16PM', '127.0.0.1', '2021-08-06 05:16:23'),
(29, 'Admin', 'Item #COK004-Cutting Board was Updated by Admin(Admin) On August 6, 2021, 01:20PM', '127.0.0.1', '2021-08-06 05:20:31'),
(30, 'Admin', 'Item #COK0010-Peeler was Updated by Admin(Admin) On August 6, 2021, 01:23PM', '127.0.0.1', '2021-08-06 05:23:16'),
(31, 'Admin', 'Item #COK009-Colander was Updated by Admin(Admin) On August 6, 2021, 01:23PM', '127.0.0.1', '2021-08-06 05:23:33'),
(32, 'Admin', 'Item #COK001-Chef Knife was Updated by Admin(Admin) On August 6, 2021, 01:34PM', '127.0.0.1', '2021-08-06 05:34:25'),
(33, 'Admin', 'Item #COK0010-Peeler was Updated by Admin(Admin) On August 6, 2021, 01:34PM', '127.0.0.1', '2021-08-06 05:34:42'),
(34, 'Admin', 'Item #COK0010-Peeler was Updated by Admin(Admin) On August 6, 2021, 01:38PM', '127.0.0.1', '2021-08-06 05:38:28'),
(35, 'Admin', 'Item #COK0015-Frying Pan was Deleted by Admin(Admin) On August 11, 2021, 06:29PM', '127.0.0.1', '2021-08-11 10:29:02'),
(36, 'Admin', 'Item #BAR002-Brandy was Updated by Admin(Admin) On August 12, 2021, 09:38PM', '127.0.0.1', '2021-08-12 13:38:25'),
(37, 'Admin', 'Item #BAR002-Brandy was Deleted by Admin(Admin) On August 12, 2021, 09:40PM', '127.0.0.1', '2021-08-12 13:40:21'),
(38, 'Peter', 'Item #BAR001-Vodka was Updated by Peter(User) On August 12, 2021, 10:37PM', '127.0.0.1', '2021-08-12 14:37:04'),
(39, 'Peter', 'Item #HSK001-Floor Mops was Updated by Peter(User) On August 12, 2021, 10:39PM', '127.0.0.1', '2021-08-12 14:39:50'),
(40, 'Admin', 'Item #FOS001-Booking was Updated by Admin(Admin) On August 13, 2021, 12:26AM', '127.0.0.1', '2021-08-12 16:26:32'),
(41, 'Admin', 'Item #FOS001-Booking was Deleted by Admin(Admin) On August 13, 2021, 12:26AM', '127.0.0.1', '2021-08-12 16:26:40'),
(42, 'Admin', 'Item #BARISTA001-Brandy was Updated by Admin(Admin) On August 13, 2021, 12:56AM', '127.0.0.1', '2021-08-12 16:56:49');

-- --------------------------------------------------------

--
-- Table structure for table `barista`
--

CREATE TABLE `barista` (
  `id` int(11) NOT NULL,
  `serialno` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `expiry_date` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `damage_item` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barista`
--

INSERT INTO `barista` (`id`, `serialno`, `name`, `brand`, `quantity`, `date_time`, `expiry_date`, `description`, `category_id`, `media_id`, `damage_item`, `remarks`) VALUES
(3, 'BARISTA001', 'Brandy', 'Fundador', 44, '2021-08-13 00:54:31', '2023-08-13', 'Brandy, alcoholic beverage distilled from wine or a fermented fruit mash. The term used alone generally refers to the grape product; brandies made from the wines or fermented mashes of other fruits are commonly identified by the specific fruit name.', 19, 0, 6, '');

-- --------------------------------------------------------

--
-- Table structure for table `bartending`
--

CREATE TABLE `bartending` (
  `id` int(11) NOT NULL,
  `serialno` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `expiry_date` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `damage_item` int(11) NOT NULL,
  `remarks` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bartending`
--

INSERT INTO `bartending` (`id`, `serialno`, `name`, `brand`, `quantity`, `date_time`, `expiry_date`, `description`, `category_id`, `media_id`, `damage_item`, `remarks`) VALUES
(1, 'BAR001', 'Vodka', 'Grey Goose', 100, '2021-08-11 12:50:02', '2023-08-11 18:50:02', 'Vodka (Polish: wódka [ˈvutka], Russian: водка [ˈvotkə], Swedish: vodka [vɔdkɑː]) is a European clear distilled alcoholic beverage.', 19, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(18, 'Appliances'),
(16, 'Cookware'),
(15, 'Dinnerware'),
(17, 'Glassware'),
(19, 'Others'),
(13, 'Preparation Tools '),
(14, 'Utensil');

-- --------------------------------------------------------

--
-- Table structure for table `cookery`
--

CREATE TABLE `cookery` (
  `id` int(11) NOT NULL,
  `serialno` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `damage_item` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cookery`
--

INSERT INTO `cookery` (`id`, `serialno`, `name`, `quantity`, `description`, `category_id`, `media_id`, `date_time`, `damage_item`, `remarks`) VALUES
(29, 'COK001', 'Chef Knife', 100, 'In cooking, a chef\'s knife, also known as a cook\'s knife, is a cutting tool used in food preparation. The chef\'s knife was originally designed primarily to slice and disjoint large cuts of beef. Today it is the primary general-utility knife for most western cooks. ', 13, 21, '2021-08-06 13:31:29', 0, ''),
(30, 'COK002', 'Cleaver Knife', 50, 'A cleaver is a large knife that varies in its shape but usually resembles a rectangular-bladed hatchet. It is largely used as a kitchen or butcher knife and is mostly intended for splitting up large pieces of soft bones and through thick pieces of meat. The knife\'s broad side can also be used for crushing in food preparation (such as garlic) and can also be used to scoop up chopped items.', 13, 22, '2021-08-06 13:31:29', 0, ''),
(31, 'COK003', 'Boning Knife', 40, 'A boning knife is a type of kitchen knife with a sharp point and a narrow blade. It is used in food preparation for removing the bones of poultry, meat, and fish. Generally 12 cm to 17 cm (5 to 6 ½ in) in length (although many brands, such as Samoan Cutlery, have been known to extend up to 9 ½ inches), it features a very narrow blade. Boning knives are not as thick-bladed as some of other popular kitchen or butcher knives, as this makes precision boning, especially deep cuts and holes easier.', 13, 23, '2021-08-06 13:31:29', 10, 'needs to sharpen'),
(32, 'COK004', 'Cutting Board', 50, 'A cutting board (or chopping board) is a durable board on which to place material for cutting. The kitchen cutting board is commonly used in preparing food; other types exist for cutting raw materials such as leather or plastic.', 13, 24, '2021-08-06 13:31:29', 0, ''),
(33, 'COK005', 'Can Opener', 50, 'A can opener (also known as a tin opener) is a device used to open steel (not tin) cans. Simple can openers, like those found in pocket knives, are operated by walking the device around the edge of the can while digging into the lid.', 13, 25, '2021-08-06 13:31:29', 0, NULL),
(34, 'COK006', 'Measuring Cup', 50, 'Liquid measuring cups are usually glass or plastic with a handle. They allow you to pour a liquid into the cup and bring it even with a measurement line without spilling. Dry measuring cups, on the other hand, hold the exact amount of an ingredient and should be leveled off with a flat edge.', 13, 26, '2021-08-06 13:31:29', 0, NULL),
(35, 'COK007', 'Measuring Spoon', 50, 'A measuring spoon is a spoon used to measure an amount of an ingredient, either liquid or dry, when cooking. Measuring spoons may be made of plastic, metal, and other materials. They are available in many sizes, including the teaspoon and tablespoon. ', 13, 27, '2021-08-06 13:31:29', 0, NULL),
(36, 'COK008', 'Mixing Bowl', 50, 'A mixing bowl is a deep bowl that is particularly well suited for mixing ingredients together in. These come in many materials, such as stainless steel, ceramic, glass, and plastic', 13, 28, '2021-08-06 13:31:29', 0, NULL),
(37, 'COK009', 'Colander', 50, 'A colander (or cullender) is a kitchen utensil used to strain foods such as pasta or to rinse vegetables. The perforated nature of the colander allows liquid to drain through while retaining the solids inside. It is sometimes also called a pasta strainer or kitchen sieve.', 19, 29, '2021-08-06 13:31:29', 0, ''),
(38, 'COK0010', 'Peeler', 50, 'A peeler (vegetable scraper) is a kitchen tool consisting of a metal blade with a slot with a sharp edge attached to a handle, used to remove the outer layer (the &quot;skin&quot; or &quot;peel&quot;) of some vegetables such as potatoes, broccoli stalks, and carrots, and fruits such as apples and pears. A paring knife may also be used to peel vegetables. The blade of a peeler has a slot with one side sharpened; the other side of the slot prevents the blade from cutting too far into the vegetable. ', 13, 30, '2021-08-06 13:31:29', 0, ''),
(39, 'COK0011', 'Mallet', 50, 'A mallet is a tool with a large, barrel-shaped, head — used to pound on something. You might use a mallet to strike an instrument or in playing croquet. ... A mallet is a long-handled implement with a barrel-shaped head used in games like croquet or polo.', 13, 31, '2021-08-06 13:31:29', 0, NULL),
(40, 'COK0012', 'Wire Whisk', 50, 'A whisk is a cooking utensil which can be used to blend ingredients smooth or to incorporate air into a mixture, in a process known as whisking or whipping. Most whisks consist of a long, narrow handle with a series of wire loops joined at the end. The loops can have different shapes depending on a whisk\'s intended functions. The wires are usually metal, but some are plastic for use with nonstick cookware.', 13, 32, '2021-08-06 13:31:29', 0, NULL),
(41, 'COK0013', 'Grater', 50, 'A grater, also known as a shredder, is a kitchen utensil used to grate foods into fine pieces. The modern grater was invented by François Boullier in the 1540s, originally to grate cheese. ', 13, 33, '2021-08-06 13:31:29', 0, NULL),
(42, 'COK0014', 'Mortar and Pestle', 50, 'Mortar and pestle, ancient device for milling by pounding. The mortar is a durable bowl commonly made of stone, ceramic, or wood. The pestle is a rounded grinding club often made of the same material as the mortar.', 13, 34, '2021-08-06 13:31:29', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `foodbev`
--

CREATE TABLE `foodbev` (
  `id` int(11) NOT NULL,
  `serialno` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `damage_item` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `foodbev`
--

INSERT INTO `foodbev` (`id`, `serialno`, `name`, `quantity`, `description`, `category_id`, `media_id`, `date_time`, `damage_item`, `remarks`) VALUES
(33, 'FBS001', 'Vodka', 50, 'Vodka (Polish: wódka [ˈvutka], Russian: водка [ˈvotkə], Swedish: vodka [vɔdkɑː]) is a European clear distilled alcoholic beverage.', 19, 0, '2021-08-11 18:26:49', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `frontoffices`
--

CREATE TABLE `frontoffices` (
  `id` int(11) NOT NULL,
  `serialno` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `damage_item` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `housekeeping`
--

CREATE TABLE `housekeeping` (
  `id` int(11) NOT NULL,
  `serialno` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `damage_item` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `housekeeping`
--

INSERT INTO `housekeeping` (`id`, `serialno`, `name`, `quantity`, `description`, `category_id`, `media_id`, `date_time`, `damage_item`, `remarks`) VALUES
(1, 'HSK001', 'Floor Mops', 40, 'A mop (such as a floor mop) is a mass or bundle of coarse strings or yarn, etc., or a piece of cloth, sponge or other absorbent material, attached to a pole or stick. It is used to soak up liquid, for cleaning floors and other surfaces, to mop up dust, or for other cleaning purposes.', 19, 0, '2021-08-12 22:35:46', 10, ''),
(2, 'HSK002', 'Broom', 50, '', 19, 0, '2021-08-12 22:46:27', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE `media` (
  `id` int(11) UNSIGNED NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `file_name`, `file_type`) VALUES
(21, 'Chef\'s_knife.jpg', 'image/jpeg'),
(22, 'Cleaver knife.jpg', 'image/jpeg'),
(23, 'boningknife.jpg', 'image/jpeg'),
(24, 'cutting_board.jpg', 'image/jpeg'),
(25, 'can_opener.jpg', 'image/jpeg'),
(26, 'measuring_cup.jpg', 'image/jpeg'),
(27, 'measuring_spoon.jpg', 'image/jpeg'),
(28, 'mixing_bowl.jpg', 'image/jpeg'),
(29, 'colander.jpg', 'image/jpeg'),
(30, 'peeler.jpg', 'image/jpeg'),
(31, 'mallet.jpg', 'image/jpeg'),
(32, 'wire whisk.jpg', 'image/jpeg'),
(33, 'grater.jpg', 'image/jpeg'),
(34, 'mortar&pestle.jpg', 'image/jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `pastry`
--

CREATE TABLE `pastry` (
  `id` int(11) NOT NULL,
  `serialno` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `media_id` int(11) NOT NULL,
  `date_time` datetime NOT NULL,
  `damage_item` int(11) DEFAULT NULL,
  `remarks` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pastry`
--

INSERT INTO `pastry` (`id`, `serialno`, `name`, `quantity`, `description`, `category_id`, `media_id`, `date_time`, `damage_item`, `remarks`) VALUES
(1, 'BPP001', 'Baking Soda', 40, 'Pastry', 19, 0, '2021-08-06 13:36:05', 12, ''),
(27, 'BPP002', 'Flour', 50, 'Use for baking bread', 19, 0, '2021-08-06 13:36:05', 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` varchar(50) DEFAULT NULL,
  `buy_price` decimal(25,2) DEFAULT NULL,
  `sale_price` decimal(25,2) NOT NULL,
  `categorie_id` int(11) UNSIGNED NOT NULL,
  `media_id` int(11) DEFAULT 0,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `quantity`, `buy_price`, `sale_price`, `categorie_id`, `media_id`, `date`) VALUES
(21, 'Empi', '100', '80.00', '90.00', 19, 0, '2021-08-06 06:14:34'),
(22, 'Fundador', '100', '95.00', '100.00', 19, 0, '2021-08-06 06:14:34');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) UNSIGNED NOT NULL,
  `product_id` int(11) UNSIGNED NOT NULL,
  `qty` int(11) NOT NULL,
  `price` decimal(25,2) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `qty`, `price`, `date`) VALUES
(13, 21, 50, '90.00', '2021-08-06'),
(14, 22, 50, '100.00', '2021-08-06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `image` varchar(255) DEFAULT 'no_image.jpg',
  `status` int(1) NOT NULL,
  `last_login` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `user_level`, `image`, `status`, `last_login`) VALUES
(1, 'Admin', 'Admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 1, 'iarq0s771.jpg', 1, '2021-08-13 00:55:58'),
(10, 'Peter', 'PeterParker', 'a8f258a2bb27be0b88661832e7a45cd5629ad051', 2, 'vmffvpxo10.jpg', 1, '2021-08-13 00:27:17'),
(11, 'Eddie Brock', 'venom', '93f792c9533345761d191e104743ac597f6c6806', 2, 'nu59ekud11.jpg', 1, '2021-08-11 18:31:55');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE `user_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(150) NOT NULL,
  `group_level` int(11) NOT NULL,
  `group_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`id`, `group_name`, `group_level`, `group_status`) VALUES
(1, 'Admin', 1, 1),
(3, 'User', 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activitylog`
--
ALTER TABLE `activitylog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barista`
--
ALTER TABLE `barista`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialno` (`serialno`),
  ADD KEY `name` (`name`,`category_id`,`media_id`);

--
-- Indexes for table `bartending`
--
ALTER TABLE `bartending`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialno` (`serialno`),
  ADD KEY `name` (`name`,`category_id`,`media_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `cookery`
--
ALTER TABLE `cookery`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialno` (`serialno`),
  ADD KEY `name` (`name`,`category_id`,`media_id`);

--
-- Indexes for table `foodbev`
--
ALTER TABLE `foodbev`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialno` (`serialno`),
  ADD KEY `name` (`name`,`category_id`,`media_id`);

--
-- Indexes for table `frontoffices`
--
ALTER TABLE `frontoffices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialno` (`serialno`),
  ADD KEY `name` (`name`,`category_id`,`media_id`);

--
-- Indexes for table `housekeeping`
--
ALTER TABLE `housekeeping`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialno` (`serialno`),
  ADD KEY `name` (`name`,`category_id`,`media_id`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `pastry`
--
ALTER TABLE `pastry`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serialno` (`serialno`),
  ADD KEY `name` (`name`,`category_id`,`media_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `categorie_id` (`categorie_id`),
  ADD KEY `media_id` (`media_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_level` (`user_level`);

--
-- Indexes for table `user_groups`
--
ALTER TABLE `user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `group_level` (`group_level`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activitylog`
--
ALTER TABLE `activitylog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `barista`
--
ALTER TABLE `barista`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bartending`
--
ALTER TABLE `bartending`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `cookery`
--
ALTER TABLE `cookery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `foodbev`
--
ALTER TABLE `foodbev`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `frontoffices`
--
ALTER TABLE `frontoffices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `housekeeping`
--
ALTER TABLE `housekeeping`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `media`
--
ALTER TABLE `media`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `pastry`
--
ALTER TABLE `pastry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_groups`
--
ALTER TABLE `user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `FK_products` FOREIGN KEY (`categorie_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `SK` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FK_user` FOREIGN KEY (`user_level`) REFERENCES `user_groups` (`group_level`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
