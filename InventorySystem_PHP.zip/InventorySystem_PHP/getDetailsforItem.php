<?php
	/*$page_title = 'All Product';
    require_once('includes/load.php');
    // Checkin What level user has permission to view this page
     page_require_level(2);
    $products = join_product_table();
	
	if(isset($_POST['id'])){
		
		
			
		$result = $conn->query("SELECT * FROM products WHERE id = '".$_POST["id"]."'");

    $output = ''; 
    foreach($products as $row)
    {
      $output .= '
      <p align="center"><img src="uploads/products/'.$row["image"].'" class="img-thumbnail" /></p>
      <p>Name : '.$row["name"].'</p>';
    }
    echo $output;
	}*/
  
$page_title = 'All Product';
    require_once('includes/load.php');
    // Checkin What level user has permission to view this page
     page_require_level(2);
    $products = join_product_table();
  if(isset($_POST["id"])){
  $output = '';
  
  foreach($products as $row)
  {
    $output = '
    <p><img src="uploads/products/'.$row["image"].'" class="img-thumbnail" /></p>
    <p><label>Name: '.$row['name'].'</label></p>
    ';
  }
  echo $output;
}
?>