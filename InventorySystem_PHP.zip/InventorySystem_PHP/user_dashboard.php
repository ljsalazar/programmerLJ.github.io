<?php
  $page_title = 'User Home Page';
  require_once('includes/load.php');
  // Checkin What level user has permission to view this page
   page_require_level(3);
?>
<?php
 $c_categorie     = count_by_id('categories');
 $c_product       = count_by_id('products');
 $c_sale          = count_by_id('sales');
 $c_user          = count_by_id('users');
 $products_sold   = find_higest_saleing_product('10');
 $recent_products = find_recent_product_added('5');
 $recent_sales    = find_recent_sale_added('5');
 $c_cookery         =count_by_id('cookery');
 $c_foodbev         =count_by_id('foodbev');
 $c_pastry         =count_by_id('pastry');
 $c_bartending         =count_by_id('bartending');
 $c_housekeeping         =count_by_id('housekeeping');
 $c_frontoffices         =count_by_id('frontoffices');
 $c_barista         =count_by_id('barista');
 $recent_cookery_added = find_recent_cookery_added('5');
 $recent_foodbev_added = find_recent_foodbev_added('5');
 $recent_pastry_added = find_recent_pastry_added('5');
 $recent_bartending_added = find_recent_bartending_added('5');
 $recent_housekeeping_added = find_recent_housekeeping_added('5');
 $recent_frontoffices_added = find_recent_frontoffices_added('5');
 $recent_barista_added = find_recent_barista_added('5');

?>
<?php include_once('layouts/header.php'); ?>

<div class="row">
   <div class="col-md-6">
     <?php echo display_msg($msg); ?>
   </div>
</div>
  <div class="row">
    <a href="users.php" style="color:black;">
		<div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-secondary1">
          <i class="glyphicon glyphicon-user"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo $c_user['total']; ?> </h2>
          <p class="text-muted">Users</p>
        </div>
       </div>
    </div>
	</a>
	
	<a href="categorie.php" style="color:black;">
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-red">
          <i class="glyphicon glyphicon-th-large"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo $c_categorie['total']; ?> </h2>
          <p class="text-muted">Categories</p>
        </div>
       </div>
    </div>
	</a>
	
	<!--<a href="product.php" style="color:black;">
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-blue2">
          <i class="glyphicon glyphicon-shopping-cart"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo $c_product['total']; ?> </h2>
          <p class="text-muted">Products</p>
        </div>
       </div>
    </div>
	</a>-->
  <a href="cookery_lab_stock_reports.php" style="color:black;">
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-blue2">
          <i class="glyphicon glyphicon-list-alt"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo $c_cookery['total'] + $c_foodbev['total'] + $c_pastry['total'] + $c_bartending['total'] + $c_housekeeping['total'] + $c_frontoffices['total'] + $c_barista['total']; ?> </h2>
          <p class="text-muted">Items On Hand</p>
        </div>
       </div>
    </div>
	</a>
	
	<a href="cookery_lab_summary_reports.php" style="color:black;">
    <div class="col-md-3">
       <div class="panel panel-box clearfix">
         <div class="panel-icon pull-left bg-green">
          <i class="glyphicon glyphicon-tasks"></i>
        </div>
        <div class="panel-value pull-right">
          <h2 class="margin-top"> <?php  echo '--' ; ?></h2>
          <p class="text-muted">Reports</p>
        </div>
       </div>
    </div>
	</a>
</div>
  <!--
  <div class="row">
   <div class="col-md-4">
     <div class="panel panel-default">
       <div class="panel-heading">
         <strong>
           <span class="glyphicon glyphicon-th"></span>
           <span>Highest Selling Products</span>
         </strong>
       </div>
       <div class="panel-body">
         <table class="table table-striped table-bordered table-condensed">
          <thead>
           <tr>
             <th>Title</th>
             <th>Total Sold</th>
             <th>Total Quantity</th>
           <tr>
          </thead>
          <tbody>
            <?php foreach ($products_sold as  $product_sold): ?>
              <tr>
                <td><?php echo remove_junk(first_character($product_sold['name'])); ?></td>
                <td><?php echo (int)$product_sold['totalSold']; ?></td>
                <td><?php echo (int)$product_sold['totalQty']; ?></td>
              </tr>
            <?php endforeach; ?>
          <tbody>
         </table>
       </div>
     </div>
   </div>
   <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
            <span>LATEST SALES</span>
          </strong>
        </div>
        <div class="panel-body">
          <table class="table table-striped table-bordered table-condensed">
       <thead>
         <tr>
           <th class="text-center" style="width: 50px;">#</th>
           <th>Product Name</th>
           <th>Date</th>
           <th>Total Sale</th>
         </tr>
       </thead>
       <tbody>
         <?php foreach ($recent_sales as  $recent_sale): ?>
         <tr>
           <td class="text-center"><?php echo count_id();?></td>
           <td>
            <a href="edit_sale.php?id=<?php echo (int)$recent_sale['id']; ?>">
             <?php echo remove_junk(first_character($recent_sale['name'])); ?>
           </a>
           </td>
           <td><?php echo remove_junk(ucfirst($recent_sale['date'])); ?></td>
           <td>$<?php echo remove_junk(first_character($recent_sale['price'])); ?></td>
        </tr>

       <?php endforeach; ?>
       </tbody>
     </table>
    </div>
   </div>
  </div>
  <div class="col-md-4">
    <div class="panel panel-default">
      <div class="panel-heading">
        <strong>
          <span class="glyphicon glyphicon-th"></span>
          <span>Recently Added Products</span>
        </strong>
      </div>
      <div class="panel-body">

        <div class="list-group">
      <?php foreach ($recent_products as  $recent_product): ?>
            <a class="list-group-item clearfix" href="edit_product.php?id=<?php echo    (int)$recent_product['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_product['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_product['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_product['name']));?>
                  <span class="label label-warning pull-right">
                 $<?php echo (int)$recent_product['sale_price']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_product['categorie'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>
 </div>
  <div class="row">

  </div>

                  -->

                  <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
              <span>Recently Added</span>
              <p>(Cookery Laboratory)</p>
              </strong>
                </div>
                  <div class="panel-body">

        <div class="list-group">
            <?php foreach ($recent_cookery_added as  $recent_cookery): ?>
            <a class="list-group-item clearfix" href="cookery_lab_edit.php?id=<?php echo    (int)$recent_cookery['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_cookery['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_cookery['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_cookery['name']));?>
                  <span class="label label-primary pull-right">
                 <?php echo (int)$recent_cookery['quantity']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_cookery['category'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>


  <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
              <span>Recently Added</span>
              <p>(Food&Beverages Laboratory)</p>
              </strong>
                </div>
                  <div class="panel-body">

        <div class="list-group">
            <?php foreach ($recent_foodbev_added as  $recent_foodbev): ?>
            <a class="list-group-item clearfix" href="foodbev_lab_edit.php?id=<?php echo    (int)$recent_foodbev['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_foodbev['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_foodbev['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_foodbev['name']));?>
                  <span class="label label-primary pull-right">
                 <?php echo (int)$recent_foodbev['quantity']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_foodbev['category'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>
 

 <div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
              <span>Recently Added</span>
              <p>(Bread&Pastry Laboratory)</p>
              </strong>
                </div>
                  <div class="panel-body">

        <div class="list-group">
            <?php foreach ($recent_pastry_added as  $recent_pastry): ?>
            <a class="list-group-item clearfix" href="pastry_lab_edit.php?id=<?php echo    (int)$recent_pastry['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_pastry['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_pastry['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_pastry['name']));?>
                  <span class="label label-primary pull-right">
                 <?php echo (int)$recent_pastry['quantity']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_pastry['category'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>




<div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
              <span>Recently Added</span>
              <p>(Bartending Laboratory)</p>
              </strong>
                </div>
                  <div class="panel-body">

        <div class="list-group">
            <?php foreach ($recent_bartending_added as  $recent_bartending): ?>
            <a class="list-group-item clearfix" href="bartending_lab_edit.php?id=<?php echo    (int)$recent_bartending['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_bartending['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_bartending['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_bartending['name']));?>
                  <span class="label label-primary pull-right">
                 <?php echo (int)$recent_bartending['quantity']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_bartending['category'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>

<div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
              <span>Recently Added</span>
              <p>(Housekeeping Laboratory)</p>
              </strong>
                </div>
                  <div class="panel-body">

        <div class="list-group">
            <?php foreach ($recent_housekeeping_added as  $recent_housekeeping): ?>
            <a class="list-group-item clearfix" href="housekeeping_lab_edit.php?id=<?php echo    (int)$recent_housekeeping['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_housekeeping['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_housekeeping['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_housekeeping['name']));?>
                  <span class="label label-primary pull-right">
                 <?php echo (int)$recent_housekeeping['quantity']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_housekeeping['category'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>

<div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
              <span>Recently Added</span>
              <p>(Front Offices Laboratory)</p>
              </strong>
                </div>
                  <div class="panel-body">

        <div class="list-group">
            <?php foreach ($recent_frontoffices_added as  $recent_frontoffices): ?>
            <a class="list-group-item clearfix" href="frontoffices_lab_edit.php?id=<?php echo    (int)$recent_frontoffices['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_frontoffices['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_frontoffices['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_frontoffices['name']));?>
                  <span class="label label-primary pull-right">
                 <?php echo (int)$recent_frontoffices['quantity']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_frontoffices['category'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>

<div class="col-md-4">
      <div class="panel panel-default">
        <div class="panel-heading">
          <strong>
            <span class="glyphicon glyphicon-th"></span>
              <span>Recently Added</span>
              <p>(Barista Laboratory)</p>
              </strong>
                </div>
                  <div class="panel-body">

        <div class="list-group">
            <?php foreach ($recent_barista_added as  $recent_barista): ?>
            <a class="list-group-item clearfix" href="barista_lab_edit.php?id=<?php echo    (int)$recent_barista['id'];?>">
                <h4 class="list-group-item-heading">
                 <?php if($recent_barista['media_id'] === '0'): ?>
                    <img class="img-avatar img-circle" src="uploads/products/no_image.png" alt="">
                  <?php else: ?>
                  <img class="img-avatar img-circle" src="uploads/products/<?php echo $recent_barista['image'];?>" alt="" />
                <?php endif;?>
                <?php echo remove_junk(first_character($recent_barista['name']));?>
                  <span class="label label-primary pull-right">
                 <?php echo (int)$recent_barista['quantity']; ?>
                  </span>
                </h4>
                <span class="list-group-item-text pull-right">
                <?php echo remove_junk(first_character($recent_barista['category'])); ?>
              </span>
          </a>
      <?php endforeach; ?>
    </div>
  </div>
 </div>
</div>


  </div><!--class="col-md-4" CookeryLab-->
  </div><!--class="col-md-4" FoodbevLab-->
  </div><!--class="col-md-4" PastryLab-->
  </div><!--class="col-md-4" BartendingLab-->
  </div><!--class="col-md-4" HousekeepingLab-->
  </div><!--class="col-md-4" FrontOfficesLab-->
  </div><!--class="col-md-4" BaristaLab-->

              
  <div class="row">

  </div>

<?php include_once('layouts/footer.php'); ?>

